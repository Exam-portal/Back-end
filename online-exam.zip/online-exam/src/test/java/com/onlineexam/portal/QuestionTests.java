
package com.onlineexam.portal;


import java.util.List;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;

import static org.junit.jupiter.api.Assertions.*;

import com.onlineexam.portal.controller.*;
import com.onlineexam.portal.dao.*;
import com.onlineexam.portal.model.*;

@SpringBootTest
class QuestionTest {

	@Autowired
	QuestionService service;
	@Autowired
	QuestionControllerException questionController;
	
	
	@Test
	void testFindAllQuestion() {
		Question question =new Question();
		question.setQuestionBankId(1);
		question.setId(2);
		question.setOptionA("A");
		question.setOptionB("B");
		question.setOptionC("C");
		question.setOptionD("D");
        service.addQuestion(question);
        
        List<Question> questionlist=service.findAllQuestion(1);
     //   assertEquals(questionlist.get(1).getQuestionBankId(),questionlist.get(1).getQuestionBankId());
	}
	

	@Test
	void testAddQuestion() {
		Question question=new Question();
		
		question.setQuestionBankId(1);
		question.setId(2);
		question.setOptionA("A");
		question.setOptionB("B");
		question.setOptionC("C");
		question.setOptionD("D");
		
		service.addQuestion(question);
		Question question1=service.findResult(question.getId());

	}

	@Test
	void testUpdateQuestion() {
		Question question = new Question();
		question.setQuestionBankId(1);
		question.setId(2);
		question.setOptionA("A");
		question.setOptionB("B");
		question.setOptionC("C");
		question.setOptionD("D");
		service.addQuestion(question);
		question.setQuestionBankId(1);
		service.update(question);
		assertEquals(true, service.update(question));
	}

	@Test
	void testDeleteQuestion() {
		Question question=service.findResult(1);
		//service.delete(question);
		List<Question> question1=service.findAllQuestion(0);
		//assertNull(question1);
		
	}
	@Test
	void testGetQuestionById() {
	Question question =new Question();
	question.setQuestionBankId(1);
	question.setId(2);
	question.setOptionA("A");
	question.setOptionB("B");
	question.setOptionC("C");
	question.setOptionD("D");
	
	
	
	}
	
	
}
